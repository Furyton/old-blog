# 微指令格式

32 bit

**31**: HALT	30..26 : S	**25** : CN	**23** : CP_PC	**22** : CP_MAR	**21** : CP_R	**20** : CP_IR	**19** : R_enable	**18** : R_wen	**17..15** : MUX_A	**14..12** : MUX_B

**11..10** : MUX_R_INA	**9..8** : MUX_R_INB	**7..6** : MUX_R_OUT	**5** : RD	**4** : WE	**3** : MUX_ADDR	**2..0** : code



**31..24** : Addr



 ## explanation

S, CN 为 ALU的操作码

R_enable : reg_file 使能信号

R_wen ：reg_file 写信号

MUX_A, MUX_B ：A，B选择器

MUX_R_INA ：A选择器中，reg_file 选择IR中哪一个位置的寄存器号

MUX_R_INB ：B选择器中，reg_file 选择IR中哪一个位置的寄存器号

MUX_R_OUT ：ALU的输出，reg_file 选择IR中哪一个位置的寄存器号

RD ：RAM读使能

WE：RAM写使能

MUX_ADDR：选择PC、MAR作为RAM地址线

code：下地址寻址方式

# ISA

参考MIPS 16bit指令集格式

指令均为单字长(16 bit)，通用寄存器有8个，均为16 bit

操作码为5位

按指令格式区分，有六类指令

- |  OPT   | R1(source) | R2(source) | R3(destination) |        |
  | :----: | :--------: | :--------: | :-------------: | :----: |
  | 5 bits |   3 bits   |   3 bits   |     3 bits      | 2 bits |

  - **ADD**， R1+R2 => R3
  - **SUB**，  R1-R2 =>  R3
  - **MULT**,  R1 * R2 => R3
  - **DIV**,      R1 / R2 => R3
  - **AND**,    R1 & R2 => R3
  - **OR**,       R1 |  R2 => R3
  - **XOR**,     R1 ^  R2 => R3
  
- |  OPT   | R1(source) |        | R3(destination) |        |
  | :----: | :--------: | :----: | :-------------: | :----: |
  | 5 bits |   3 bits   | 3 bits |     3 bits      | 2 bits |

  - **NOT**,    ~R1 => R3
  - **SHL**,     R1<<1 => R3
  - **SHR**      R1>>1 => R3
  - **MOV**,    R1 => R3
  - **LD**,        M[R1] => R3
  - **ST**,         R1 => M[R3]
  
- |  OPT   | R1(destination) | Immediate number(source) |
  | :----: | :-------------: | :----------------------: |
  | 5 bits |     3 bits      |          8 bits          |

  - **MVH**      immediate => High_Byte(R1)
  - **MVL**       immediate => Low_Byte(R1)
  
- |  OPT   | R1(source) | R2(destination) | Immediate number |
  | :----: | :--------: | :-------------: | :--------------: |
  | 5 bits |   3 bits   |     3 bits      |      5 bits      |

  - **ADDI**      R1 + immediate => R2
  - **SUBI**       R1 - immediate => R2
  
- |  OPT   |   R1   |       |
  | :----: | :----: | :---: |
  | 5 bits | 3 bits | 8bits |

  - **UJMP**     PC jumps unconditionally to R1
  - **CJMP**      PC jumps to R1 when C0 = 1
  - **ZJMP**       PC jumps to R1 when FZ = 1
  - **MOVSP**   R1 => SP
  - **PUSH**       push R1 => stack[SP], SP ++
  - **POP**          stack[SP] => R1,  SP--
  - **CALL**         run subroutine at R1

- |  OPT   |         |
  | :----: | :-----: |
  | 5 bits | 11 bits |
  
  - **RET**           return from subroutine
  - **RST**           0 => PC
  - **HALT**         1 => halt

## 与讲义中的设计不同的地方

- 通用寄存器数量、指令字长等均有所增加。
- ALU拥有更多其他的功能，如无符号整数乘法、高（低）位byte的操作、存储A、B输入是否相等、结果是否溢出等等。
- 指令的功能更加丰富，包括基本的逻辑和算术运算、有（无）条件跳转、栈的操作、简单的子程序调用等。
- A、B选择器并没有设计为互斥，故ALU的A、B输入端可以同时传入。
- PC、MAR、通用寄存器等的时钟脉冲没有设计为互斥，可以在同一上升沿中一起进行寄存。
- 下地址字段的设计进行了改动，如：100表示下一个微地址为取指指令所在的微程序，简化了指令的微程序编写。
- 指令均为单字长指令，且大部分为寄存器寻址，每条指令的微程序大大简化。
- 缺点：由于指令集的精简，一些原本基本的操作可能需要1-3个指令才能实现。

## CPU电路设计图

### CPU核心

![CPU core](C:\Users\Furyton\OneDrive\Workspace\Quartus\core.png)

### 控制电路（微程序控制）

![](C:\Users\Furyton\Desktop\MyBlog\themes\cards\source\upload_image\CU.png)

### CPU整体

![](C:\Users\Furyton\Desktop\MyBlog\themes\cards\source\upload_image\microcodeCPU.png)

## 数据通路

### 通用寄存器选择方式

#### ALU 的输入

由于指令中有三个固定的位置上会出现寄存器的编号，因此设置了两层选择器，第一个是用来选择是启用指令中的R1、R2还是R3，第二个是A，B选择器，两个选择器都能够选择输入寄存器中的数据，即reg_files 为双端口输出。

#### ALU的输出

输出只需选择启用指令中的R1、R2还是R3。

#### 说明

指令上的选择器保留了00，即寄存器000号。它被作为SP（Stack Pointer）



### 数据通路
- reg_file: 通用寄存器组，8*16 bit，双端口输出
- ALU ： 有S0...S4，CN六个控制端，用以选择运算类型
- 寄存器C0，FZ：分别用来保存ALU产生的进位信号和A、B相等信号
- RAM：读写操作分别收WE和RE信号控制
- MAR：RAM的地址寄存器
- IR：指令寄存器

数据通路采用CPU内部三总线方式

- 寄存器之间的数据传输
	- $R1 \overset{A 选择器}{\rightarrow} ALU \overset{A 直传}{\rightarrow} R2$
- RAM 和 CPU之间的数据传输
	- $PC/MAR \overset{Bus, RE=1}{\rightarrow} RAM \overset{A 选择器} ALU \overset{A 直传}{\rightarrow} IR$
	- $PC/MAR \overset{Address Bus, WE=1}{\rightarrow} RAM, ALU \overset{Data Bus}{\rightarrow} RAM$
- 算术运算
	- $R1(IR) \overset{A 选择器}{\rightarrow} ALU, R2(IR) \overset{B 选择器}{\rightarrow} ALU, ALU \overset{S, CN}{\rightarrow} R3(IR)$
	- $PC  \overset{B 选择器}{\rightarrow} ALU  \overset{B + 1}{\rightarrow} PC $

## 指令流程

![](C:\Users\Furyton\Desktop\MyBlog\themes\cards\source\upload_image\指令执行流程.png)

## 测试指令

